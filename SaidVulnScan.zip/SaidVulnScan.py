
import os

def scan(ip):
    print(f"[+] Scanning IP: {ip}")
    os.system(f"nmap -sV {ip}")

ip = input("Geli IP address: ")
scan(ip)
