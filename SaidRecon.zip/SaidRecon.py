
import requests
import socket

def get_ip(domain):
    try:
        return socket.gethostbyname(domain)
    except:
        return "IP not found"

def get_headers(domain):
    try:
        r = requests.get(f"http://{domain}")
        return r.headers
    except:
        return "Failed to fetch headers"

domain = input("Fadlan geli domain-ka ama IP: ")
print("IP Address:", get_ip(domain))
print("HTTP Headers:", get_headers(domain))
